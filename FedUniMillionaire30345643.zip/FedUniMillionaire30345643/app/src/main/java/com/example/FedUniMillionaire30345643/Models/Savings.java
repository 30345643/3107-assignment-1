package com.example.FedUniMillionaire30345643.Models;

public class Savings {
    private int amount;

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
